function login() {
    var usernameInput = document.getElementById('username');
    var passwordInput = document.getElementById('password');
    var resultDiv = document.getElementById('result');

    var username = usernameInput.value;
    var password = passwordInput.value;


    if (username.trim() === '') {
        resultDiv.innerHTML = "<p class='invalid-comment'>El Usuario y contraseña son obligatorios.</p>";
        return;
    } else if (username.length < 5 || username.length > 15) {
        resultDiv.innerHTML = "<p class='invalid-comment'>Usuario debe tener entre 5 y 15 caracteres.</p>";
        return;
    } else {
        resultDiv.innerHTML = "<p class='valid-comment'>Usuario válido.</p>";
    }


    if (password.trim() === '') {
        resultDiv.innerHTML += "<p class='invalid-comment'>Contraseña es obligatoria.</p>";
        return;
    } else if (password.length < 6 || password.length > 8) {
        resultDiv.innerHTML += "<p class='invalid-comment'>Contraseña debe tener entre 6 y 8 caracteres.</p>";
        return;
    } else {
        resultDiv.innerHTML += "<p class='valid-comment'>Contraseña válida.</p>";
    }

    
    var validUsers = {
        "userA": "123456",
        "userX": "654321",
        "userJ": "QWERTY",
        "userR": "qwerty",
        "userI": "ytrewq"
    };

    if (validUsers[username] && validUsers[username] === password) {
        resultDiv.innerHTML += "<p class='valid-comment'>¡Bienvenido, " + username + "!</p>";
    } else {
        resultDiv.innerHTML += "<p class='invalid-comment'>Credenciales incorrectas. Inténtalo de nuevo.</p>";
    }
}

function togglePassword() {
    var passwordInput = document.getElementById('password');
    var toggleButton = document.querySelector('button');

    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        toggleButton.textContent = 'Ocultar Contraseña';
    } else {
        passwordInput.type = 'password';
        toggleButton.textContent = 'Mostrar Contraseña';
    }
}
